#!/bin/bash
# Define la ruta de binarios
PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
# Uptime
up=("$(uptime -p | awk '{$1=""; sub("  ", " "); print}')")
# Host
host=("$(hostname)")
# IPs del sistema
meu_ip=("$(ifconfig | awk '/inet addr/{print substr($2,6)}' | awk 'NR==1{print $1}')")
# Data/hora
data=("$(date +"%Y-%m-%d")")
hora=("$(date +"%T")")
# Servicos iniciados en el boot
servicos=("$(ls -1 /etc/rc$(/sbin/runlevel| cut -d" " -f2).d/S* | awk -F'[0-9][0-9]' '{print " Servico :-> " $2}' | sort -k 3)")
### Define parametros de e-mail ###
email="mimail@midominio.com"        # E-mail destino de alerta
assunto=$host": [Alert] Restart ["$meu_ip"]" # Asunto de email
# Envio de email
printf "%b\n" "Sistema [$host] ($meu_ip) reiniciado en $data.\n
Uptime: $up\n
Cargados en el inicio:\n$servicos" | mail -s "$assunto" "$email"
# Espera 10s para que se envíen los mails
sleep 10
# Reinicia el sistema
reboot
